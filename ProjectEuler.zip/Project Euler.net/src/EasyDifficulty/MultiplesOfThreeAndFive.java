package EasyDifficulty;

public class MultiplesOfThreeAndFive {
	/* mistakes
	 * --------
	 * 1. Overthought
	 * 2. Lack of knowledge of +=
	 * 3. incorrect placing of print method
	 */
	private static int sum = 0;

	public static void main(String[] args) {
		for (int i = 1; i < 1000; i++) {
			if (i % 3 == 0 || i % 5 == 0) {
				sum += i;

			}
			
		}
		System.out.println(sum);
	}
}
