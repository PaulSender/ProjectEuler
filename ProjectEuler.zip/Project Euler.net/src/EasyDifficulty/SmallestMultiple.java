package EasyDifficulty;
import java.util.Arrays;
public class SmallestMultiple {
	
	

}