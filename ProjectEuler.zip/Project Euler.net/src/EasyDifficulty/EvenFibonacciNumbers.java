package EasyDifficulty;
/*
 * Mistakes
 * --------
 * 1. Not enough understanding of java language
 * 2. Needed to access a previous and next term
 * 3. Didn't know how to deal with a stack overflow
 * 
 */
public class EvenFibonacciNumbers {
	static int previous = 0;
	static int next = 1;
	static int bound = 4000000;
	static int evenSum = 0;

	public static void main(String[] args) {
		boolean exceed = false;
		while (!exceed) {
			int newFib = previous + next;
			previous = next;
			next = newFib;
			if (newFib > bound) {
				exceed = true;
				break;
			}
			if (newFib % 2 == 0) {
				evenSum += newFib;
			}
		}
		System.out.println(evenSum);
	}
}
