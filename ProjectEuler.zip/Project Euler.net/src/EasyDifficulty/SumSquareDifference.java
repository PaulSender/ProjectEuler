package EasyDifficulty;

public class SumSquareDifference {
	public static void main(String[] args) {
		System.out.println(squareSumNaturalNumbers() - sumOfNaturalsSquared());
	}

	public static int squareSumNaturalNumbers() {
		int sum = 0;
		for (int i = 1; i <= 100; i++) {
			sum += i;
		}
		return sum * sum;
	}

	public static int sumOfNaturalsSquared() {
		int sum = 0;
		int temp = 0;
		for (int i = 1; i <= 100; i++) {
			temp = i * i;
			sum += temp;
		}
		return sum;
	}
}
